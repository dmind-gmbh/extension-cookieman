# 2.2.3

## MISC
- fix #31 split TypoScript into Base + Examples 449049f
- fix #33 sort group.trackingsObjects by key and prevent JSON-object-cast e6dae65
- remove outdated reference to test extension fa2cf1f
- run composer-normalize 57f32e4
- add composer-normalize 4457db0
- speed-up startup ff1b61f
- depend on the test setup (--dev) dc839cc
- docs b19231b
- fix #32 make examples CSP-ready dcbbed9
- copy all nodes from injects() - get rid of container 2651790
- configure bootstrap-package to not use inline WebFontLoader (breaks CSP) 41d8413
- remove dependencies from test extension 8f8fb64
- minify 4401c03
- include Content-Security-Policy in our test extensions & use our Crowdin Widget as test case e0e69df
- fix #28 s attributes not properly inserted 95ccb4d
- customize TypoScript in test extension 7cd65c3
- fix typo 1a0d155
- make JS more error-tolerant (here: arbitrary cookie values) 7df502d
- fix all test extensions being active 1df885a

# 2.2.0

## MISC
- give animations more time 409168f
- use PHP 7.3 locally ffa06de
- generalize URL for non-site package testing 718d666
- update README badges 56de0b0
- split Github actions into ‹CGL & unit› and ‹acceptance› tests. Use ddev with a patch to run acceptance tests in Github actions. ef44cc6
- align pre-commit with new composer {scripts} 04714de
- add composer typo3:flush command de4c6c2
- refactor composer {scripts} 0f5c552
- bump PHP version for TYPO3v10 f73d324
- fix bootstrap3-banner aa3d1ab
- use codeception to run acceptance tests 0313d3a
- manual 3-way merge to align translations (#25) c0bef29
- New translations locallang.xlf (French) (#20) 453cce9
- Revert "run coveralls only when secret is available" f5843e0
- run coveralls only when secret is available d5143d3
- New translations locallang.xlf (French) (#17) 9bdad89
- New Crowdin translations (#14) 083dccd
- New Crowdin translations (#11) b64f79d
- New Crowdin translations (#9) 2c95642
- remove unused .crowdin.yml 6141ccf
- Update Crowdin configuration file 9e319c5
- New Crowdin translations (#6) fc802c2
- add links 1270a32
- fix test badge 2848a18
- remove workflow dependency 9d0a210
- revert last idea 0fa6e8f
- run composer and coveralls only one in workflow a45385e
- add unit test badge 03f1e72
- use deprecated method to stay compatible with PHPUnit 6.5 1950d49
- run unit tests with PHP 7.2 + 7.3 69c3c32
- add code coverage checking 0b43503
- add composer 145cf66
- add docker test container 24358de
- add DataProcessor test 0108fbd
- use relative symlink to make it work host- and ddev-wise 50dbe04
- shorten local startup time 4657b4e
- add .gitconfig for local dev e466687
- remove .crowdin.yaml from export 2d6cf24

# 2.1.14

## MISC
- remove  from templates (small is really small...) addbc59
- fix xdebug (again...) 3d659dd
- fix docker-env e9c071d
- ignore yarn error logs bd544e3
- add notice about CDNs 675704e
- document defaults 578b423
- document showOnce() b78a527
- format docs 8d9ee59
- document minify b4a3d5a
- explain extensing types b2677d8
- add notice about weird versioning a5f7c7a
- New translations locallang.xlf (Romanian) ff8cc5f
- New translations locallang.xlf (Spanish) 5a4d06f
- New translations locallang.xlf (Romanian) 41add10
- New translations locallang.xlf (French) 73338a9
- New translations locallang.xlf (Romanian) 5a318b1
- New translations locallang.xlf (German) a5afdbe
- New translations locallang.xlf (Danish) 7c59cfd
- New translations locallang.xlf (Danish) 7b54170
- format documentation ab04282
- add TER link c4d7c0c
- remove title branding... 7eb84e1
- more documentation 1fc6af0
- more documentation 1c4e8a3

# 2.1.8

## MISC
- showcase theme customizing aa94202
- describe theme customizing 99ba259
- change description 493d648

# 2.1.5

## MISC
- adapt release script 56412c2
- add dependency to ext_emconf.php 505646e

# 2.1.2

## MISC
- README (2) 0ce5094
- README fb0bcf0
- use SEL for Typo3v9+ bc69c6e
- make minify configurable a1a2ec3
- New translations locallang.xlf (Vietnamese) 444c28b
- New translations locallang.xlf (Catalan) 6588ccf
- New translations locallang.xlf (Chinese Simplified) ce74d2d
- New translations locallang.xlf (Czech) 518c25a
- New translations locallang.xlf (Danish) 4dbfd16
- New translations locallang.xlf (Dutch) f9a016f
- New translations locallang.xlf (Finnish) 3695641
- New translations locallang.xlf (French) 875cbd6
- New translations locallang.xlf (German) 0fc76fb
- New translations locallang.xlf (Greek) c82ff54
- New translations locallang.xlf (Hebrew) b5d3e1c
- New translations locallang.xlf (Hungarian) efd5ee9
- New translations locallang.xlf (Arabic) 34a4298
- New translations locallang.xlf (Italian) b580adf
- New translations locallang.xlf (Korean) 10646e1
- New translations locallang.xlf (Norwegian) 9d881b8
- New translations locallang.xlf (Polish) 1a9d93d
- New translations locallang.xlf (Portuguese) 0ac80cb
- New translations locallang.xlf (Romanian) f87053c
- New translations locallang.xlf (Russian) 3bc1ed9
- New translations locallang.xlf (Serbian (Cyrillic)) 84f71ec
- New translations locallang.xlf (Spanish) fd38acc
- New translations locallang.xlf (Swedish) fd7e105
- New translations locallang.xlf (Turkish) 9b3b8c7
- New translations locallang.xlf (Ukrainian) 775a6ee
- New translations locallang.xlf (Japanese) c289424
- New translations locallang.xlf (Afrikaans) f10be1f
- New translations locallang.xlf (Vietnamese) 7d7d051
- New translations locallang.xlf (Catalan) ca8c80c
- New translations locallang.xlf (Chinese Simplified) 7ca2334
- New translations locallang.xlf (Czech) 55ee6b4
- New translations locallang.xlf (Danish) 07b15ef
- New translations locallang.xlf (Dutch) 4a92e7a
- New translations locallang.xlf (Finnish) 19a295e
- New translations locallang.xlf (French) a56e054
- New translations locallang.xlf (Greek) 7213773
- New translations locallang.xlf (Hebrew) 63b9b67
- New translations locallang.xlf (Hungarian) 69deef3
- New translations locallang.xlf (Arabic) 155e763
- New translations locallang.xlf (Italian) 9cf860d
- New translations locallang.xlf (Korean) abd9a51
- New translations locallang.xlf (Norwegian) 911fd2c
- New translations locallang.xlf (Polish) 9fef8cc
- New translations locallang.xlf (Portuguese) 004d836
- New translations locallang.xlf (Romanian) 75795da
- New translations locallang.xlf (Russian) b74481c
- New translations locallang.xlf (Serbian (Cyrillic)) 04cec38
- New translations locallang.xlf (Spanish) 864f251
- New translations locallang.xlf (Swedish) bca402a
- New translations locallang.xlf (Turkish) cd98d13
- New translations locallang.xlf (Ukrainian) 1d15275
- New translations locallang.xlf (Japanese) a6517f7
- New translations locallang.xlf (Afrikaans) bfe0388
- New translations locallang.xlf (Chinese Simplified) f17c75b
- New translations locallang.xlf (Chinese Traditional) 379a483
- New translations locallang.xlf (Portuguese) 0950247
- New translations locallang.xlf (Portuguese, Brazilian) 9703834
- cleanup 1cbe840

# 2.0.10

## MISC
- compile JS 3465b0d
- edit example - finally had the idea how to fix the translation-via-TypoScript issue. 4dedd42
- add example e5b2132
- use DataProcessor to enable settings overwritability 9b51e4e
- add release process to composer 6ca6741
- compile JS 1958bd2
- add minify config 28490d9
- add screenshots 01572ed
- add Matomo cookie descriptions 4e113ce
- Update Crowdin configuration file 8571085
- Merge remote-tracking branch 'origin/l10n_master' f8b9f27
- New translations locallang.xlf (German) b5eb839
- add more bs4-accordion fixes 8ef784b
- add group description 4051133
- New translations locallang.xlf (German) 81a28f8
- New translations locallang.xlf (Vietnamese) e7e7ce4
- New translations locallang.xlf (Afrikaans) 4c7eee1
- New translations locallang.xlf (Arabic) 922fc6c
- New translations locallang.xlf (Catalan) 40dd0f9
- New translations locallang.xlf (Chinese Simplified) f0562d7
- New translations locallang.xlf (Chinese Traditional) 377fd99
- New translations locallang.xlf (Czech) 8effa0b
- New translations locallang.xlf (Danish) c90afda
- New translations locallang.xlf (Dutch) ddc00a2
- New translations locallang.xlf (Finnish) e5b3b20
- New translations locallang.xlf (Greek) 460a55d
- New translations locallang.xlf (Hebrew) e09158a
- New translations locallang.xlf (Hungarian) ada5df8
- New translations locallang.xlf (Italian) a59d684
- New translations locallang.xlf (Korean) 37e7978
- New translations locallang.xlf (Norwegian) c35197f
- New translations locallang.xlf (Polish) 27e2ad1
- New translations locallang.xlf (Portuguese) 2545780
- New translations locallang.xlf (Portuguese, Brazilian) d46950b
- New translations locallang.xlf (Romanian) 22d3384
- New translations locallang.xlf (Russian) f067f35
- New translations locallang.xlf (Serbian (Cyrillic)) f99b987
- New translations locallang.xlf (Spanish) fbb73b3
- New translations locallang.xlf (Swedish) 8cdf2f6
- New translations locallang.xlf (Turkish) 62eeb61
- New translations locallang.xlf (Ukrainian) 44fb77f
- New translations locallang.xlf (Japanese) 331f6c2
- New translations locallang.xlf (French) 9bfe65b
- gear bootstrap4-modal towards conservative example 9bbb3e8
- dynamify bootstrap3-modal 3fa10ad
- add TypoScript docs and starter kit, rename, clean up 2939206
- add TODO 02e1b92
- add test extensions for each theme and crowdin link; enable bootstrap4-modal by default 4266153
- dynamify bootstrap3-banner b9b8ea0
- use partial for table rows 1844e5f
- factor common variables out of template 5881ab0
- add some more translations 0deebbd
- toggle tags instead of ::after (make it translatable) 8028a4a
- beautify bootstrap4-modal 02632f5
- fix HTML reflow, refactor 0ea02dc
- New translations locallang.xlf (Chinese Simplified) 896402f
- New translations locallang.xlf (Chinese Traditional) 16da56a
- New translations locallang.xlf (Portuguese) aa67f86
- New translations locallang.xlf (Portuguese, Brazilian) a9dea96
- New translations locallang.xlf (Vietnamese) fb97146
- New translations locallang.xlf (Afrikaans) 5d3bd39
- New translations locallang.xlf (Arabic) dbe9ace
- New translations locallang.xlf (Catalan) f5102c8
- New translations locallang.xlf (Chinese Simplified) aa9ecd3
- New translations locallang.xlf (Chinese Traditional) cdbecc7
- New translations locallang.xlf (Czech) 7dac91e
- New translations locallang.xlf (Danish) 880578f
- New translations locallang.xlf (Dutch) 79e1f27
- New translations locallang.xlf (Finnish) cbae3de
- New translations locallang.xlf (Greek) 232cd87
- New translations locallang.xlf (Hebrew) 3dc6fb1
- New translations locallang.xlf (Hungarian) 49586f3
- New translations locallang.xlf (Italian) 40030c2
- New translations locallang.xlf (Korean) 760ef53
- New translations locallang.xlf (Norwegian) 80ae153
- New translations locallang.xlf (Polish) a5c338a
- New translations locallang.xlf (Portuguese) ef83405
- New translations locallang.xlf (Portuguese, Brazilian) 8152b09
- New translations locallang.xlf (Romanian) a502727
- New translations locallang.xlf (Russian) 95be69f
- New translations locallang.xlf (Serbian (Cyrillic)) a7f7f0e
- New translations locallang.xlf (Spanish) 5b5ba4e
- New translations locallang.xlf (Swedish) 8cff360
- New translations locallang.xlf (Turkish) 0c4ff9f
- New translations locallang.xlf (Ukrainian) 502ec19
- New translations locallang.xlf (Japanese) 4ea8744
- New translations locallang.xlf (French) 25778ee
- New translations locallang.xlf (Vietnamese) 34c2140
- New translations locallang.xlf (German) fb3844e
- New translations locallang.xlf (Afrikaans) e0c51f5
- New translations locallang.xlf (Arabic) 547314a
- New translations locallang.xlf (Catalan) 97704d6
- New translations locallang.xlf (Chinese Simplified) 209c8e3
- New translations locallang.xlf (Chinese Traditional) 90d3506
- New translations locallang.xlf (Czech) 14b6fda
- New translations locallang.xlf (Danish) 165d898
- New translations locallang.xlf (Dutch) 636323b
- New translations locallang.xlf (Finnish) dda8e0f
- New translations locallang.xlf (Greek) def394c
- New translations locallang.xlf (Hebrew) 1b76e67
- New translations locallang.xlf (Hungarian) 2ab1f61
- New translations locallang.xlf (Italian) 1cde8f0
- New translations locallang.xlf (Korean) 6f49ef0
- New translations locallang.xlf (Norwegian) 4f5a106
- New translations locallang.xlf (Polish) 8fc9cbf
- New translations locallang.xlf (Portuguese) c9476a1
- New translations locallang.xlf (Portuguese, Brazilian) 4ba770b
- New translations locallang.xlf (Romanian) 1f3b2a3
- New translations locallang.xlf (Russian) 212954c
- New translations locallang.xlf (Serbian (Cyrillic)) aba6192
- New translations locallang.xlf (Spanish) 6063b57
- New translations locallang.xlf (Swedish) 8cfab84
- New translations locallang.xlf (Turkish) f7610c9
- New translations locallang.xlf (Ukrainian) 1af07b5
- New translations locallang.xlf (Japanese) 923ad58
- New translations locallang.xlf (German) 1ecb789
- New translations locallang.xlf (French) 6bee25b
- New translations locallang.xlf (English) 8215469
- fix typo e2368d9
- beautify xlf 847933e
- New translations locallang.xlf (German) 5e241a7
- New translations locallang.xlf (French) d2f8e74
- New translations locallang.xlf (English) e7e3f88
- add resname to xlf a31af0a
- New translations locallang.xlf (German) a69118e
- New translations locallang.xlf (French) f119560
- New translations locallang.xlf (English) 6d82f0e
- beautify xlf 1ec129c
- New translations locallang.xlf (German) 38ab661
- New translations locallang.xlf (French) c8f0c8c
- New translations locallang.xlf (English) 1c5b1b7
- fix typo f65605c
- New translations locallang.xlf (German) 33fec6d
- New translations locallang.xlf (French) a695bc3
- New translations locallang.xlf (English) 5e10f6c
- translate source (EN) 7b28fc2
- add new ddev command ‹launch› d2a90d7
- remove explicitly disabled DNT functionality abf2e9b
- New translations locallang.xlf (German) a52128f
- New translations locallang.xlf (German) 8b4a25c
- add TODO b2517f8
- add crowdin widget and badge 86ec10b
- New translations locallang.xlf (German) 5a0552c
- New translations locallang.xlf (French) 20d3c8d
- New translations locallang.xlf (English) 594e37d
- test crowdin - changing source language string 4a74820
- New translations locallang.xlf (German) 8930c36
- New translations locallang.xlf (French) 249e9f5
- Update Crowdin configuration file 16e51bf
- add TODO e9b495d

# 2.0.5

## MISC
- use bootstrap4-modal as default theme b78fdd1
- mention w.i.p. in README 6d33124
- remove debug da9ba6d
- inject HTML, take special care of  67fbf07
- add TODOs 71cb2cc
- fix exportToHtml abeaacd
- add translations (w.i.p.) ee33a35
- adapt to new TypoScript structure 0e5ba77
- export some settings to HTML 5bc4697
- refactor TypoScript, add TypoScript examples 58577b7
- use partial across default themes b9df4e4
- add rootPaths sequence resourceBasePath › default themes › default a8c7985
- set bootstrap 4 as default 3f41550

# 2.0.2-dev

## MISC
- use release:create d3fb2a2
- add release:publish script f208fb5
- enable bootstrap_package compatiblity e94aece
- config via TypoScript; translation 26233b3
- modernize TypoScript include f3a430d
- style card-body e5e48b0
- use bootstrap4 in master/v10 7975b88
- amend TODO c2305df
- amend TODO e93cedf
- cleanup c6913c7

# 1.3.4

## MISC
- add TODO section 19d353c
- add extension-helper 95471be
- use composer update e591a94
- Bootstrap 4 theme b37e9fb
- alias branches to 2.x-dev 46c105f
- remove private Satis e89af7b
- fix .md syntax 880b003
- fix homepage 9cadb56
- remove private Satis c22b03e
- document typo3-console (not!) usage 8b657da
- add cookieman test config 77591eb
- adapt to missing Configuration/TypoScript 5e69179
- fix extension nomenclature 605d1c6
- reorder extension installation 8e8ac1c
- export data from ddev dump-db into writable fs e8a571b
- clean up ddev config 4ac1910
- composer.json dependencies and scripts ecff94a
- add GPLv2 0c1e3c2
- prevent php-cs exporting 676a8ee
- fix PHP d95f80e
- setup TypoScript in cookieman_test 303e255
- add pre-commit CGL hook 84ac154
- add unit tests skeleton fc28183
- emconf f93b49f
- .gitignore fcefdb9
- github issue templates 88c7e7c
- php-cs-fixer 3a00558
- basic JS/CSS build config 5f0674b
- configure git eol and export aeef693
- .editorconfig 1a95786
- beautify 68196ca
- ddev config aa42aca
- add testing extension b3a7f4c
- change default theme e736baa
- use default bootstrap colors // justify text b5a8e8b
- justify text 383f07e
- vertically center collapse indicators 2a8cbd8
- translate common texts 4dfb1a5
- use more usual colors for default theme dec4286
- lint 96f9d9f
- refactor initialisation and JS theme integration e666a7e
- add .gitignore a53d38f

# 1.3.1

## MISC
- drop double e.preventDefault() 6b3afee

# 1.3.0

## MISC
- bump version f6357d3
- remove styling 68fc52a

# 1.2.2

## MISC
- Bump version afd1c16
- docs 74009aa
- docs 62a6e78
- docs f0f0d59
- remove client specific texts e3c20d3
- remove client specific texts 114bb6b

# 1.2.1

## MISC
- bump version 74e447a

# 1.2.0

## MISC
- docs 9c89b3d
- streamline examples (2) 4573e78
- streamline examples (1) 1d17bcc
- include fallback for Fluid paths 3de8f0f

# 1.1.1

## MISC
- bump version f906f2c
- bump version 712f71e

# 1.1.0

## MISC
- bump version 50c9c8f
- add imprint PID to constants; suppress showing popup on imprint/data declaration pages 683fc49
- docs a3cd1e5

# 1.0.0

## MISC
- version constraints 8c5c5e4
- v1.0.0 965dd21

# 0.1.0

## MISC
- pre-stable b89fc5e
- initial 165ae21

