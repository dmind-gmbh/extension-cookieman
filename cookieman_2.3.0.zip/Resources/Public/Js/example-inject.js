// won't work in IE11 https://developer.mozilla.org/en-US/docs/Web/API/Document/currentScript
console.log('cookieman: I would inject ' + document.currentScript.dataset.what + ' now...')
