# 1.3.2

## MISC
- add TODO section 493ae6f
- add extension-helper c854e20
- use composer update 4c0526f
- Bootstrap 4 theme 174b2f8
- alias branches to 2.x-dev 14ca713
- remove private Satis a2ec4ce
- fix .md syntax 7359869

# 2.0.0-alpha+v8

## MISC
- fix homepage d66cafc
- remove private Satis 7c57e92
- add cookieman test config 5c4e025
- setup TYPO3v8 6d9e86d
- adapt to missing Configuration/TypoScript 3ec05db
- add v9 templates 17b2ec5
- fix extension nomenclature babe7c2
- set TYPO3 v9 c9705b4
- reorder extension installation b35fa68
- export data from ddev dump-db into writable fs b1488a5
- clean up ddev config 0c82b86
- composer.json dependencies and scripts ecff94a
- add GPLv2 0c1e3c2
- prevent php-cs exporting 676a8ee
- fix PHP d95f80e
- setup TypoScript in cookieman_test 303e255
- add pre-commit CGL hook 84ac154
- add unit tests skeleton fc28183
- emconf f93b49f
- .gitignore fcefdb9
- github issue templates 88c7e7c
- php-cs-fixer 3a00558
- basic JS/CSS build config 5f0674b
- configure git eol and export aeef693
- .editorconfig 1a95786
- beautify 68196ca
- ddev config aa42aca
- add testing extension b3a7f4c
- change default theme e736baa
- use default bootstrap colors // justify text b5a8e8b
- justify text 383f07e
- vertically center collapse indicators 2a8cbd8
- translate common texts 4dfb1a5
- use more usual colors for default theme dec4286
- lint 96f9d9f
- refactor initialisation and JS theme integration e666a7e
- add .gitignore a53d38f

# 1.3.1

## MISC
- drop double e.preventDefault() 6b3afee

# 1.3.0

## MISC
- bump version f6357d3
- remove styling 68fc52a

# 1.2.2

## MISC
- Bump version afd1c16
- docs 74009aa
- docs 62a6e78
- docs f0f0d59
- remove client specific texts e3c20d3
- remove client specific texts 114bb6b

# 1.2.1

## MISC
- bump version 74e447a

# 1.2.0

## MISC
- docs 9c89b3d
- streamline examples (2) 4573e78
- streamline examples (1) 1d17bcc
- include fallback for Fluid paths 3de8f0f

# 1.1.1

## MISC
- bump version f906f2c

# 1.1.0

## MISC
- bump version 712f71e
- bump version 50c9c8f
- add imprint PID to constants; suppress showing popup on imprint/data declaration pages 683fc49
- docs a3cd1e5

# 1.0.0

## MISC
- version constraints 8c5c5e4
- v1.0.0 965dd21

# 0.1.0

## MISC
- pre-stable b89fc5e
- initial 165ae21

